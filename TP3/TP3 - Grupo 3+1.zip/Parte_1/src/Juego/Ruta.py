class Ruta:
    def __init__(self,destino,trafico):
        self.destino = destino
        self.trafico = trafico