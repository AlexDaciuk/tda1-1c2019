## logica de combate implementada en Juego.Juego
## Mudar para aca